from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException        
import time
import random
password=input("enter password to login to script")
if not(password=="Khalil2015"):
   print("password incorrect")
   exit()

user="hadsazerza@gmail.com"
driver = webdriver.Chrome()
driver.get("file:///home/khalil/Documents/scripts/gamil/ok/index.html")
time.sleep(3)
email= driver.find_element_by_id("username").send_keys(user)
driver.find_element_by_id("generate").click()
time.sleep(5)
driver.find_element_by_id("emails").click()
driver.find_element_by_id("save").click()
print("the password of emails is Khalil2015")
